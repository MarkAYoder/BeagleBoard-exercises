__all__ = ["basic", "classification", "detection"]

__version__ = '1.2.0000'
