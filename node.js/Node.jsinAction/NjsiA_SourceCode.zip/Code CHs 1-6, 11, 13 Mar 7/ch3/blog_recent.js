var http = require('http')
  , mysql = require('mysql'); 

var client = mysql.createClient({ 
  user:     'myuser',
  password: 'mypassword',
});

client.useDatabase('blog'); 

http.createServer(function (req, res) { 
  if (req.url == '/') {
    client.query( 
      "SELECT * FROM posts \
        ORDER BY timestamp DESC \
        LIMIT 5",
      function(err, results, fields) { 
        if (err) throw err;

        var output = 'html';

        res.writeHead(200, {'Content-Type': 'text/html'});
        res.end(output); 
      }
    );
  }
}).listen(8000, "127.0.0.1");