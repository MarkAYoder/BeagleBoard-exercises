var assert = require('assert')
  , todo = require('../lib/todo')
  , todoDb = new todo.TodoDb();

describe('todo', function() { 

  before(function() {
    todoDb = new todo.TodoDb();
  });

  it('should be able to delete', function(done) { 
    todoDb.delete(function() {
      todoDb.get({'skip': 0, 'limit': 25}, function(err, todos) {
        if (err) throw err;
        assert.equal( 
          todos.length,
          0,
          'Failure: there should be no todos after deleting them'
        );
        done();
      });
    });
  });

  after(function() {
    todoDb.close();
  });
});