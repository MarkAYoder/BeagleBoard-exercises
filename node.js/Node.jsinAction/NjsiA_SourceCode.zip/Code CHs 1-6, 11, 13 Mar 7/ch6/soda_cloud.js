var browser = soda.createSauceClient({
  'url': 'http://www.reddit.com/'
, 'username': 'yourusername' 
, 'access-key': 'youraccesskey' 
, 'os': 'Windows 2003' 
, 'browser': 'firefox' 
, 'browser-version': '3.6' 
, 'name': 'This is an example test'
, 'max-duration': 300 
});