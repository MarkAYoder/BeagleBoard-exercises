var express = require('express')
  , app = express.createServer();

app.get('/about', function(req, res) {
  res.send( 
    + 'html'
  );
});

module.exports = app;