var vows = require('vows')
  , assert = require('assert')
  , todo = require('./lib/todo')
  , todoDb = new todo.TodoDb();

vows.describe('todo application').addBatch({ 
  'todo deletion': { 
    topic: function () { 
      var callback = this.callback;
      todoDb.delete(function() {
        todoDb.get(
          {'skip': 0, 'limit': 25},
          callback
        );
      });
    },
    'get after deletion': function(err, todos) { 
      assert.equal(todos.length, 0);
      todoDb.close();
    }
  }
}).run();