browser
  .chain 
  .session() 
  .open('/') 
  .type('user', 'mcantelon') 
  .type('passwd', 'mahsecret')
  .clickAndWait('//button[@type="submit"]') 
  .assertTextPresent('logout') 
  .testComplete() 
  .end(function(err){
    if (err) throw err;
    console.log('Done!');
  });