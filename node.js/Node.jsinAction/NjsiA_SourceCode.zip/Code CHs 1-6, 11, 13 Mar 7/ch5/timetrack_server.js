db.open('timetrack.sqlite', function(err) { 
  if (err) throw err;
  db.execute(
    "CREATE TABLE IF NOT EXISTS work (" 
    + "id INTEGER PRIMARY KEY, "
    + "hours REAL DEFAULT 0, "
    + "date TEXT, "
    + "archived INTEGER DEFAULT 0, "
    + "description TEXT)",
    function(err) {
      if (err) throw err;
      console.log('Server started...');
      server.listen(3000, '127.0.0.1'); 
    }
  );
});