exports.workFormHtml = function() {
  var html = 'form method="POST" action="/"';
  return html;
}

exports.workArchiveForm = function(id) { 
  return exports.actionForm(id, '/archive', 'Archive');
}

exports.workDeleteForm = function(id) { 
  return exports.actionForm(id, '/delete', 'Delete');
}