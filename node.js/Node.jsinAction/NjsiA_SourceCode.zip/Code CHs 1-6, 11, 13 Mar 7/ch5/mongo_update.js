var _id = new client.bson_serializer
                    .ObjectID('4e650d344ac74b5a01000001');
collection.update(
  {_id: _id},
  {$set: {a: 3}},
  {safe: true},
  function(err) {
    if (err) throw err;
  }
);