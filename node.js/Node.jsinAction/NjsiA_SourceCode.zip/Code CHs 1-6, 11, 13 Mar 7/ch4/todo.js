...
case 'DELETE':                     
  var path = url.parse(req.url).pathname
    , i = parseInt(path.slice(1), 10);
  
  if (isNaN(i)) {                  
    res.statusCode = 400;
    res.end('Invalid item id');
  } else if (!items[i]) {          
    res.statusCode = 404;
    res.end('Item not found');
  } else {
    items.splice(i, 1);            
    res.end('OK\n');
  }
  break;
...