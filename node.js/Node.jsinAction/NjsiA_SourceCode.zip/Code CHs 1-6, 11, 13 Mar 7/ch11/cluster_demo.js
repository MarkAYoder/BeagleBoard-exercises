var cluster = require('cluster')
  , http = require('http')
  , numCPUs = require('os').cpus().length; 

if (cluster.isMaster) {
  for (var i = 0; inumCPUs; i++) {
